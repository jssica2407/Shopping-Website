<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>意見回饋 | EasyWear</title>
    </head>

    <body>
        <?php
        include 'customMenu.php'; 
        include 'Feedback.html';
        ?>
    </body>
</html>