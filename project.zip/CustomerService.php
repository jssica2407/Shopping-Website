<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>客服中心 | EasyWear</title>
    </head>

    <body>
        <?php
        include 'customMenu.php'; 
        include 'CustomerService.html';
        ?>
    </body>
</html>