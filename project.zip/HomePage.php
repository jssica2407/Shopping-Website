<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>主頁 | EasyWear</title>
    </head>

    <body>
        <?php
        include 'customMenu.php';
        include 'HomePage.html';
        ?>
    </body>
</html>