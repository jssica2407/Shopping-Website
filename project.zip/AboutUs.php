<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8"/>
        <title>關於我們 | EasyWear</title>
    </head>

    <body>
        <?php
        include 'customMenu.php';
        include 'AboutUs.html';
        ?>
    </body>
</html>