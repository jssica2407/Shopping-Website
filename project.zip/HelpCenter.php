<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>幫助中心 | EasyWear</title>
    </head>

    <body>
        <?php
        include 'customMenu.php';
        include 'HelpCenter.html';
        ?>
    </body>
</html>