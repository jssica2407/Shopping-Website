<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8"/>
        <title>尺碼換算指南 | EasyWear </title>
    </head>
    
    <body>
        <?php
        include 'customMenu.php'; 
        include 'SizeGuide.html';
        ?>
    </body>
</html>